#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 was not found."
    echo "On Chromebook Linux, run: sudo apt update && sudo apt install -y python3"
    exit 1
fi

echo "Starting KNOX IP PINGER PRO for Chromebook..."
python3 knox_pinger_chromebook.py
