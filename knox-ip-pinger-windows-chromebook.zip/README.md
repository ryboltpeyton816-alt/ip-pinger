# KNOX IP PINGER PRO

Two Python versions are included:
- `knox_pinger_windows.py` — Windows Command Prompt / PowerShell.
- `knox_pinger_chromebook.py` — Chromebook Linux (Crostini) terminal.

## Requirements
- Python 3
- The system `ping` command
- On Chromebook, Linux development environment enabled

## Run on Windows
Open Command Prompt or PowerShell in this folder:
```powershell
py knox_pinger_windows.py
```
If `py` is unavailable:
```powershell
python knox_pinger_windows.py
```

## Run on Chromebook
Open the Linux Terminal in this folder:
```bash
python3 knox_pinger_chromebook.py
```

## Login
- Username: `Knox`
- Password: `123`

The password is visible while typing in this starter version. Change these credentials before sharing the code publicly.

## Features
- Custom IPv4 or IPv6 target entered when starting a ping session
- Configurable interval (1–1000 seconds)
- Ping count (1000 or more, or unlimited)
- Reply timeout (1–2000 seconds)
- Packet size and TTL settings
- Alternating dark navy and dark red terminal output
- Ctrl+C stops the current ping session

## Notes
Use only against devices and networks you own or have permission to test. A 2000-second reply timeout can make an unresponsive ping appear to hang for a long time. Ping options and permissions can vary by operating system and network.
