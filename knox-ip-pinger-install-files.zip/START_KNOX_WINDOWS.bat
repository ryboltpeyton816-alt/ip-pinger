@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON=py"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo Python 3 was not found.
        echo Install Python from https://www.python.org/downloads/
        echo During setup, enable "Add Python to PATH".
        pause
        exit /b 1
    )
    set "PYTHON=python"
)

echo Starting KNOX IP PINGER PRO for Windows...
%PYTHON% knox_pinger_windows.py
pause
