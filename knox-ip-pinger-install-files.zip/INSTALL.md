# Install and run KNOX IP PINGER PRO

There are no third-party Python packages to install. You only need Python 3 and the operating system's `ping` command.

## Windows

1. Install Python 3 from https://www.python.org/downloads/ if it is not already installed. During setup, enable **Add Python to PATH**.
2. Download the repository (Code → Download ZIP) and extract it.
3. Keep `START_KNOX_WINDOWS.bat` in the same folder as `knox_pinger_windows.py`.
4. Double-click `START_KNOX_WINDOWS.bat`.

Or open PowerShell in that folder and run:

```powershell
py knox_pinger_windows.py
```

## Chromebook

1. Turn on the Linux development environment in Chromebook Settings.
2. Open the Linux Terminal and install Python if needed:

```bash
sudo apt update
sudo apt install -y python3
```

3. Download the repository ZIP, extract it, and place the files in the same folder.
4. In Terminal, change to that folder and run:

```bash
python3 knox_pinger_chromebook.py
```

Or run the included launcher:

```bash
chmod +x START_KNOX_CHROMEBOOK.sh
./START_KNOX_CHROMEBOOK.sh
```

## Login in this starter build

- Username: `Knox`
- Password: `123`

**Security:** This starter build has a simple hardcoded login, not secure account authentication. Do not use the starter password for sensitive access. If publishing the source publicly, anyone can inspect the code and see the credentials; change or remove the login before publishing.

## Notes

Only ping systems you own or have permission to test. The configured timeout is the maximum wait for a reply to one ping; a high timeout can make an unresponsive target appear to pause for a long time.
