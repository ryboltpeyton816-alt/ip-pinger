import os
import platform
import re
import subprocess
import time
import ipaddress

NAVY = "\033[38;2;0;0;90m"
DARK_RED = "\033[38;2;130;0;0m"
GREEN = "\033[92m"
WHITE = "\033[97m"
RESET = "\033[0m"

BANNER = r"""___  ________        ________  ___  ________   ________  _______   ________
|\  \|\   __  \      |\   __  \|\  \|\   ___  \|\   ____\|\  ___ \ |\   __  \
\ \  \ \  \|\  \     \ \  \|\  \ \  \ \  \\ \  \ \  \___|\ \   __/|\ \  \|\  \
 \ \  \ \   ____\     \ \   ____\ \  \ \  \\ \  \ \  \  __\ \  \_|/_\ \   _  _\
  \ \  \ \  \___|      \ \  \___|\ \  \ \  \\ \  \ \  \|\  \ \  \_|\ \ \  \\  \|
  \ \__\ \__\          \ \__\    \ \__\ \__\\ \__\ \_______\ \_______\ \__\\ _\
   \|__|\|__|           \|__|     \|__|\|__| \|__|\|_______\|_______|\|__|\|__|"""

target = "1.1.1.1"
interval = 1.0
count_limit = 1000
timeout_seconds = 2000
packet_size = 56
ttl = 64

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def show_banner():
    print(NAVY + BANNER + RESET)
    print(WHITE + "                    KNOX IP PINGER PRO" + RESET)
    print()

def login():
    clear()
    show_banner()
    print("LOGIN")
    username = input("Username: ")
    password = input("Password: ")
    if username == "Knox" and password == "123":
        print(GREEN + "LOGIN SUCCESSFUL" + RESET)
        input("Press ENTER to continue...")
        return True
    print(DARK_RED + "LOGIN FAILED" + RESET)
    time.sleep(2)
    return False

def settings():
    global target, interval, count_limit, timeout_seconds, packet_size, ttl
    while True:
        clear()
        show_banner()
        print("========== SETTINGS ==========")
        print("1. Default target IP:", target)
        print("2. Ping interval:", interval, "seconds")
        print("3. Ping count:", count_limit if count_limit else "UNLIMITED")
        print("4. Reply timeout:", timeout_seconds, "seconds")
        print("5. Packet size:", packet_size, "bytes")
        print("6. TTL:", ttl)
        print("7. Back")
        choice = input("\\nChoose: ").strip()
        try:
            if choice == "1":
                target = str(ipaddress.ip_address(input("Default IP: ").strip()))
            elif choice == "2":
                value = float(input("Interval (1-1000 seconds): "))
                if 1 <= value <= 1000:
                    interval = value
                else:
                    print("Choose 1 through 1000."); time.sleep(2)
            elif choice == "3":
                value = input("Ping count (1000+ or U for unlimited): ").strip().lower()
                if value == "u":
                    count_limit = 0
                elif value.isdigit() and int(value) >= 1000:
                    count_limit = int(value)
                else:
                    print("Choose at least 1000 or U."); time.sleep(2)
            elif choice == "4":
                value = int(input("Reply timeout (1-2000 seconds): "))
                if 1 <= value <= 2000:
                    timeout_seconds = value
                else:
                    print("Choose 1 through 2000."); time.sleep(2)
            elif choice == "5":
                value = int(input("Packet size (0-65500 bytes): "))
                if 0 <= value <= 65500:
                    packet_size = value
                else:
                    print("Invalid packet size."); time.sleep(2)
            elif choice == "6":
                value = int(input("TTL (1-255): "))
                if 1 <= value <= 255:
                    ttl = value
                else:
                    print("TTL must be 1-255."); time.sleep(2)
            elif choice == "7":
                return
        except ValueError:
            print("Invalid input."); time.sleep(2)

def build_ping_command(ip):
    system = platform.system().lower()
    if system == "windows":
        # Windows -w uses milliseconds.
        return ["ping", "-n", "1", "-w", str(timeout_seconds * 1000),
                "-l", str(packet_size), "-i", str(ttl), ip]
    # Linux / ChromeOS Linux environment: -W uses seconds.
    return ["ping", "-n", "-c", "1", "-W", str(timeout_seconds),
            "-s", str(packet_size), "-t", str(ttl), ip]

def run_pinger():
    clear()
    show_banner()
    raw_ip = input("ENTER IP ADDRESS TO PING: ").strip()
    try:
        ip = str(ipaddress.ip_address(raw_ip))
    except ValueError:
        print(DARK_RED + "Invalid IP address." + RESET)
        input("Press ENTER...")
        return

    sent = received = 0
    clear()
    show_banner()
    print("TARGET:", ip)
    print("INTERVAL:", interval, "seconds")
    print("REPLY TIMEOUT:", timeout_seconds, "seconds")
    print("COUNT:", count_limit if count_limit else "UNLIMITED")
    print("\\nPress CTRL+C to stop.\\n")
    try:
        while count_limit == 0 or sent < count_limit:
            sent += 1
            color = NAVY if sent % 2 else DARK_RED
            try:
                result = subprocess.run(
                    build_ping_command(ip), capture_output=True, text=True,
                    timeout=timeout_seconds + 5
                )
                if result.returncode == 0:
                    received += 1
                    match = re.search(r"time[=<]([\\d.]+)", result.stdout, re.I)
                    latency = match.group(1) + " ms" if match else "Reply received"
                    print(color + f"[{sent}] REPLY | {ip} | {latency}" + RESET)
                else:
                    print(color + f"[{sent}] NO REPLY | {ip}" + RESET)
            except subprocess.TimeoutExpired:
                print(color + f"[{sent}] TIMEOUT | {ip}" + RESET)
            if count_limit == 0 or sent < count_limit:
                time.sleep(interval)
    except KeyboardInterrupt:
        print("\\nPING STOPPED")
    print(WHITE + "\\n========== RESULTS ==========" + RESET)
    print("Sent:", sent, "| Received:", received, "| Lost:", sent - received)
    input("\\nPress ENTER to return...")

def main():
    if not login():
        return
    while True:
        clear()
        show_banner()
        print("1. START IP PINGER")
        print("2. SETTINGS")
        print("3. EXIT")
        choice = input("\\nSelect: ").strip()
        if choice == "1":
            run_pinger()
        elif choice == "2":
            settings()
        elif choice == "3":
            break

if __name__ == "__main__":
    main()
